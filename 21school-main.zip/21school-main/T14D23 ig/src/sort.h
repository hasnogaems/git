#ifndef SRC_SORT_H_
#define SRC_SORT_H_

#include <stdio.h>

void heapSort(FILE* fp, int n);
void heapify(FILE* fp, int n, int i);

#endif