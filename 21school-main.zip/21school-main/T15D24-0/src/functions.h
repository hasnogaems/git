#ifndef SRC_FUNCTIONS_H_
#define SRC_FUNCTIONS_H_

#include "libs.h"

int getLastId(FILE* ptr);
int checkId(FILE* ptr, int id);

#endif  // SRC_FUNCTIONS_H_
