#include <stdio.h>
int main() {
    printf("%s", "Hello, AI!");
    return 0;
}