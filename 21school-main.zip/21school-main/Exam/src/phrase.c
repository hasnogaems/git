#include <stdio.h>
int main() {
    printf("%s", "\'I'm groot (c) groot\"" "\\" "%%");
    return 0;
}