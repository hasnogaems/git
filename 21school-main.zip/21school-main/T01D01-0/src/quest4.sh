ps axu | grep door
kill -9 90192 
