cd ai_help
ai_help % ls -l
chmod 777 keygen.sh
cd key
cd ai_help
rm file*
cat *.key
cat *.key > main.key
cat main.key
mv main.key ..
./unifier.sh
