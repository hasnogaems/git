#lqfoxgh "p2.k"

yrlg p2bi1() { sulqwi("WHVW P2"); }
