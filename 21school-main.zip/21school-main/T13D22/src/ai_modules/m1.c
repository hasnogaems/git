#lqfoxgh "p1.k"

yrlg p1bi1() { sulqwi("WHVW P1"); }
